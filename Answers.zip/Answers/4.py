import socket
import hashlib

HOST = '127.0.0.1'
PORT = 8080

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
    server.bind((HOST, PORT))
    server.listen(5)  # Allow up to 5 pending connections
    print(f"Server listening on {HOST}:{PORT}")

    while True:
        conn, addr = server.accept()  # Accept a new connection
        with conn:
            print(f"Connected by {addr}")
            while True:
                try:
                    data = conn.recv(1024)
                    if not data:  # No more data, close connection
                        break
                    hash_digest = hashlib.sha256(data).hexdigest()
                    conn.sendall(hash_digest.encode('utf-8'))
                except Exception as e:
                    print(f"Error: {e}")
                    break
